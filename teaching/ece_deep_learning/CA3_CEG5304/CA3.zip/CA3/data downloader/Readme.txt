You can either download the data manually, or use this provided script to download it.

To run the script,

bash ./download_dataset.sh monet2photo